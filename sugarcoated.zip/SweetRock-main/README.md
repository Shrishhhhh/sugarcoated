<p align="center">
<img src="https://raw.githubusercontent.com/cryptoAlgorithm/SweetRock/main/app/src/main/res/drawable/large_icon.webp" width="180" />
</p>
<h1 align="center">Sweet Rock</h1>
<p align="center">Curated, fictitious food to instantly satisfy every craving</p>
<p align="center">
  <a href="https://play.google.com/store/apps/details?id=com.cryptoalgo.sweetRock">
    <img src="https://play.google.com/intl/en_us/badges/static/images/badges/en_badge_web_generic.png" width="240" />
  </a>
</p>

Satisfy your food ordering cravings with Sweet Rock! Our app offers a
wide variety of cuisines curated by our team of food experts, from classic
comfort foods to trendy fusion dishes. Order mouth-watering dishes from
our multicultural menu to your heart's content without spending a cent!

> Disclaimer:
> Please note that this is a fictitious app, and any resemblance to real
> restaurants or dishes is purely a coincidence. You will not be able to
> order real food through this app, nor will you be able to spend real money.

